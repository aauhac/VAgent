"""
Analysis service — validates uploads and delegates to job runner.
"""

from __future__ import annotations

import os
import shutil
import uuid
from pathlib import Path
from typing import Any, Optional

from fastapi import UploadFile

from ..jobs.runner import JobRunner, validate_analysis_id

SUPPORTED_EXT = {".mp3", ".wav", ".m4a", ".flac", ".ogg", ".aac", ".webm", ".mp4", ".m4v"}


class AnalysisService:
    def __init__(self) -> None:
        from ..config import get_runtime_dir

        self.runtime_dir = get_runtime_dir()
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        self.max_upload_mb = float(os.environ.get("MAX_UPLOAD_MB", "30"))
        self.runner = JobRunner(self.runtime_dir)

    async def enqueue_upload(
        self,
        *,
        file: UploadFile,
        separate: bool = False,
        include_feedback: bool = False,
        analysis_mode: str = "QUICK",
        input_mode: str = "AUTO",
        user_id: str = "anon",
        user_provider: str = "DEV",
    ) -> str:
        filename = file.filename or "upload.bin"
        ext = Path(filename).suffix.lower()
        if ext not in SUPPORTED_EXT:
            raise ValueError(
                f"unsupported file type '{ext}'. allowed: {sorted(SUPPORTED_EXT)}"
            )

        mode = (analysis_mode or "QUICK").upper()
        in_mode = (input_mode or "AUTO").upper()
        if mode == "FUNCTIONAL":
            separate = in_mode != "VOCAL_ONLY"

        analysis_id = uuid.uuid4().hex
        job_dir = self.runtime_dir / analysis_id
        job_dir.mkdir(parents=True, exist_ok=True)

        dest = job_dir / f"upload{ext}"
        size = 0
        max_bytes = int(self.max_upload_mb * 1024 * 1024)
        with open(dest, "wb") as out:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > max_bytes:
                    out.close()
                    shutil.rmtree(job_dir, ignore_errors=True)
                    raise ValueError(f"file too large (max {self.max_upload_mb} MB)")
                out.write(chunk)

        try:
            from .history_service import write_analysis_meta

            write_analysis_meta(
                analysis_id,
                user_id=user_id or "anon",
                filename=filename,
                analysis_mode=mode,
                input_mode=in_mode,
                separate=separate,
                runtime_dir=self.runtime_dir,
            )
        except Exception:
            # Metadata write must not block enqueue
            pass

        try:
            self._maybe_persist_db_row(
                analysis_id=analysis_id,
                user_id=user_id or "anon",
                user_provider=user_provider or "DEV",
                filename=filename,
                mode=mode,
                in_mode=in_mode,
                separate=separate,
            )
        except Exception:
            pass

        self.runner.submit(
            analysis_id=analysis_id,
            audio_path=str(dest),
            separate=separate,
            include_feedback=include_feedback,
            analysis_mode=mode,
            input_mode=in_mode,
        )
        return analysis_id

    def _maybe_persist_db_row(
        self,
        *,
        analysis_id: str,
        user_id: str,
        user_provider: str = "DEV",
        filename: str,
        mode: str,
        in_mode: str,
        separate: bool,
    ) -> None:
        from ..config import database_url

        if not database_url():
            return
        from ..db.analysis_repo import get_user_by_subject
        from ..db.models import Analysis
        from ..db.session import session_scope
        from ..db.users import get_or_create_user

        with session_scope() as session:
            user = get_user_by_subject(session, user_id)
            if user is None:
                provider = (user_provider or "DEV").strip().upper() or "DEV"
                user = get_or_create_user(session, provider=provider, subject=user_id)
            if session.get(Analysis, analysis_id):
                return
            session.add(
                Analysis(
                    id=analysis_id,
                    user_id=user.id,
                    status="queued",
                    stage="queued",
                    progress=0,
                    analysis_mode=mode,
                    input_mode=in_mode,
                    separate=separate,
                    original_filename=filename,
                    audio_storage_key=f"{analysis_id}/upload{Path(filename).suffix.lower()}",
                )
            )

    def get_job(self, analysis_id: str) -> Optional[dict[str, Any]]:
        if not validate_analysis_id(analysis_id):
            return None
        return self.runner.get(analysis_id)

    def delete_job(self, analysis_id: str) -> bool:
        if not validate_analysis_id(analysis_id):
            return False
        from .deletion import delete_analysis_content

        result = delete_analysis_content(self.runtime_dir, analysis_id)
        if result.ok:
            self.runner.mark_deleted(analysis_id)
        return result.ok

    def preview_path(self, analysis_id: str) -> Optional[Path]:
        return self.runner.resolve_preview_path(analysis_id)

    def load_full_analysis(self, analysis_id: str) -> Optional[dict[str, Any]]:
        """Load full analysis.json (server-side). Not for free public API."""
        if not validate_analysis_id(analysis_id):
            return None
        path = self.runtime_dir / analysis_id / "analysis.json"
        if not path.exists():
            return None
        try:
            import json

            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None

    def entitlements(self):
        from ..entitlements import get_entitlement_provider

        return get_entitlement_provider(self.runtime_dir)
